from __future__ import print_function
import boto3
import urllib

print('Loading function')

glue = boto3.client('glue')

def lambda_handler(event, context):
    
    s3_bucket = event['detail']['bucket']['name']
    print("Bucket name is {}".format(s3_bucket))
    
    s3_key = urllib.parse.unquote_plus(event['detail']['object']['key'], encoding='utf-8')
    print("Bucket key name is {}".format(s3_key))
    
    filename = s3_key.split('/')[-1]
    print(filename)
    
    if filename == "Job-834-mom-ar-bal_part00000.csv":
        gluejobname = "ETL_834_mom_ar_bal"
    
    elif filename == "Job-filecomparison_part00000.csv":
        gluejobname = "ETL_filecomparison"
    
    elif filename == "Job-mpr-je_part00000.csv":
        gluejobname = "ETL_mpr_je"
    
    elif filename == "job-prt-mpr-addr-change-dhcs-834_part00000.csv":
        gluejobname = "ETL_prt_mpr_addr_change_dhcs_834"
    
    elif filename == "Job-soc-data_part00000.csv":
        gluejobname = "ETL_soc_data"
        
    elif filename == "Job-834-mom-ar-bal-streamed_part00000.csv":
        gluejobname = "ETL_834_mom_ar_bal_sourcestream"
    
    elif filename == "Job-filecomparison-streamed_part00000.csv":
        gluejobname = "ETL_filecomparison_sourcestream"
    
    elif filename == "Job-mpr-je-streamed_part00000.csv":
        gluejobname = "ETL_mpr_je_sourcestream"
    
    elif filename == "Job-prt-mp-addr-change-dhcs-834-streamed_part00000.csv":
        gluejobname = "ETL_prt_mpr_addr_change_dhcs_834_sourcestream"
    
    elif filename == "Job-soc-data-streamed_part00000.csv":
        gluejobname = "ETL_soc_data_sourcestream"
    
    else:
        gluejobname = ""

        
    print("GlueJobname: " +gluejobname)

    try:
        runId = glue.start_job_run(JobName=gluejobname)
        status = glue.get_job_run(JobName=gluejobname, RunId=runId['JobRunId'])
        print("Job Status : ", status['JobRun']['JobRunState'])
    except Exception as e:
        error_msg = str(e)
        # print(error_msg) do required action
        raise e
