import boto3
import json
import base64
import requests


bucket_name = 'integrationframeworktarget'
#file_name = 'Hello World.pdf'
#file_name = 'DimDoctor_new.csv'
    
def lambda_handler(event, context):
    s3 = boto3.client('s3')
        #endpoint_url='https://s3.ap-south-1.amazonaws.com',
        #region_name='ap-south-1')
    
    file = event['body']
    #decodedBytes = base64.b64decode(file)
    #decodedStr = decodedBytes.decode("ascii")
    #json_str=json.loads(decodedStr)
    print('file>>>>',file)
    #print(json_str)
   # data = event.body
    print('event>>>>',event)
    
    file_str = file.strip('\"')
    print('file_str>>>>>',file_str)

#Generate the presigned URL
    URL = s3.generate_presigned_url("put_object", Params={"Bucket": bucket_name, "Key": file_str}, ExpiresIn=600)
    #URL = s3.generate_presigned_post(Bucket=bucket_name, Key=file_name, Fields=None, Conditions=None, ExpiresIn=360)
    
  #  print(URL)
    
   # get_file_content = event["content"]  
   # decode_content = base64.b64decode(get_file_content)
    
   # s3_upload = s3.put_object(Bucket="integrationframework", Key='Hello World.pdf', Body=decode_content)
    
    #with open(object_name, 'rb') as f:
    #files = {'file': (object_name, f)}
    #http_response = requests.post(response['url'], data=response['fields'], files=files)
    
    return {
         "isBase64Encoded": True,
         'statusCode': 200,
         "headers": {
             "Content-Type": "application/json",
             'Access-Control-Allow-Origin': '*'
         },
    #    "event": json.dumps(file),
    #     "file": file,
     #    "decode": decode_content,
    #     "body": json.dumps({"file": file})
         "body": json.dumps({"URL": URL})
    }