import json
import os
import boto3
import csv
import urllib.parse
import time

#initiate s3 client 
s3 = boto3.client('s3')

# The kinesis stream defined in asw console
stream_name = 'KinesisDataStreamSample'
k_client = boto3.client('kinesis', region_name='ap-south-1')


def lambda_handler(event, context):
    print("event collected is {}".format(event))
    print("Received event: " + json.dumps(event, indent=2))
    
    s3_bucket = event['detail']['bucket']['name']
    print("Bucket name is {}".format(s3_bucket))
    
    s3_key = urllib.parse.unquote_plus(event['detail']['object']['key'], encoding='utf-8')
    print("Bucket key name is {}".format(s3_key))
    
    infile = s3_key.split('/')[-1]
    print(infile)
    
    path, filename = os.path.split(s3_key)
    print(path)
    print(filename)
    
    from_path = "/tmp/{}".format(filename)
    print("from path {}".format(from_path))



    #Download object to the file    
    s3.download_file(
        Bucket=s3_bucket,
        Key=s3_key,
        Filename=from_path
    )
    print("donwloaded successfully....")


    print('after connection....')
    #curs = connection.cursor()
    print('after cursor....')
    
    # opening the CSV file
    with open(from_path, mode ='r')as file:
   
        # reading the CSV file
        csvFile = csv.reader(file)
        #print(csvFile)
        
        #Skip heder record 
        #next(csvFile, None)
        
        # displaying the contents of the CSV file
        for lines in csvFile:
            #print(type(lines))
            #print(lines)

            #querry = "INSERT INTO PatientCount (rownumber,providernpi,fullname,count_patientnumber) VALUES ({}, {}, '{}', {});".format(lines[0], lines[1], lines[2], lines[3])
            #querry = "select rownumber,providernpi,fullname,count_patientnumber from PatientCount"
            #querry = "INSERT INTO PatientCount (rownumber,providernpi,fullname,count_patientnumber) VALUES (2, 98765, 'Dr. Two', 4);"
            #querry = "INSERT INTO PatientCount (rownumber,providernpi,fullname,count_patientnumber) VALUES (%s, %s, %s, %s);"
            #print("query is {}".format(querry))
            #print('after querry....')
            #curs.execute("INSERT INTO PatientCount (rownumber,providernpi,fullname,providerspecialty,count_patientnumber) VALUES (%s, %s, %s, %s, %s);", (lines[0], lines[1], lines[2], lines[3], lines[4]))
            data = ', '.join(lines)
            the_data = str(infile) + "," + str(data)
            print("Data :" + str(the_data))
            
            put_to_stream(the_data,infile)
            
            # wait for 1 second
            time.sleep(0.1)
    
    os.remove(from_path)
    print('file removed from lambda storage....')          
            
def put_to_stream(the_data,infile):
    
    payload = the_data
    part_key = infile
    print (payload)
	
    put_response = k_client.put_record(
                            StreamName=stream_name,
                            Data=str(payload),
                            PartitionKey=part_key)
	                        
    #print('wow..executed....')


      