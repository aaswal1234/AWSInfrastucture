import json
import os
import boto3
import csv
import urllib.parse
import time
import pandas as pd
from io import BytesIO
import s3fs


#initiate s3 client 
s3 = boto3.client('s3')



def lambda_handler(event, context):
    #print("event collected is {}".format(event))
    #print("Received event: " + json.dumps(event, indent=2))
    
    s3_bucket = event['detail']['bucket']['name']
    print("Bucket name is {}".format(s3_bucket))
    
    s3_key = urllib.parse.unquote_plus(event['detail']['object']['key'], encoding='utf-8')
    print("Bucket key name is {}".format(s3_key))
    
 
    resp = s3.get_object(Bucket=s3_bucket, Key=s3_key)
    print(resp)

    ###########################################
    # one of these methods should work for you. 
    # Method 1
    df = pd.read_csv(resp['Body'], sep=',')
    #
    # Method 2
    # df = pd.read_csv(BytesIO(resp['Body'].read().decode('utf-8')))
    ###########################################
    ##print(df.head(1))   
    
    first_column = df.columns[0]
    print("Filename is:" + str(first_column))
    
    if first_column == "834_mom_ar_bal.csv":
        prefix = "intermediate/streamdataFirehose/834_mom_ar_bal/"
    
    elif first_column == "filecomparison.csv":
        prefix = "intermediate/streamdataFirehose/filecomparison/"
    
    elif first_column == "mpr_je.csv":
        prefix = "intermediate/streamdataFirehose/mpr_je/"
    
    elif first_column == "prt_mpr_addr_change_dhcs_834.csv":
        prefix = "intermediate/streamdataFirehose/prt_mpr_addr_change_dhcs_834/"
    
    elif first_column == "soc_data.csv":
        prefix = "intermediate/streamdataFirehose/soc_data/"
    
    else:
        prefix = "intermediate/streamdataFirehose/"
        
    prefix = "AthenaQueryResult/"
    
    
    df[first_column] = df[first_column].str.strip().str.title()
    unique_values = df[first_column].unique()
    print(unique_values)
    
    for unique_value in unique_values:
        df_output = df[df[first_column].str.fullmatch(unique_value)]
        print(df_output.head(3))
        
        new_header = df_output.iloc[0] #grab the first row for the header
        df_output = df_output[1:] #take the data less the header row
        df_output.columns = new_header
        print(df_output.head(3))
        
        
        #output_path = output_dir / f"{unique_value}.xlsx"
        
        df_data = df_header.drop([first_column], axis=1)
        print(df_data.head(3))
    
        pathwithfile = "/tmp/{}".format(first_column)
    
        df_data = df_data.replace(r"^ +| +$", r"", regex=True)
        print(df_data.head(3))
    
    #        #csv_file = df_data.to_csv(pathwithfile, encoding='utf-8', index=False)
    
        output_key = prefix + str(unique_value)
    
        print(output_key)
    
    
    
        #df_data.to_csv(f's3://{s3_bucket}/{output_key}', sep=',', index=False)
    
    
    
    
    #os.remove(pathwithfile)
    print('file removed from lambda storage....') 
    
    return {
        'statusCode': 200,
        'body': 'Output file created successfully in S3'
    }   