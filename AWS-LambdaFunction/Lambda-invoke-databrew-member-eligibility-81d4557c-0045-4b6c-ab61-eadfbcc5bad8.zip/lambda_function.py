from __future__ import print_function
import boto3
import urllib

print('Loading function')

databrew = boto3.client('databrew')

def lambda_handler(event, context):
    
    s3_bucket = event['detail']['bucket']['name']
    print("Bucket name is {}".format(s3_bucket))
    
    s3_key = urllib.parse.unquote_plus(event['detail']['object']['key'], encoding='utf-8')
    print("Bucket key name is {}".format(s3_key))
    
    filename = s3_key.split('/')[-1]
    print(filename)
    
    folder = s3_key.split('/')[-3]
    print(folder)
    
    if filename == "834_mom_ar_bal.csv" and folder != "streamdataFirehose":
        jobname = "Job-834-mom-ar-bal"
    
    elif filename == "filecomparison.csv" and folder != "streamdataFirehose":
        jobname = "Job-filecomparison"
    
    elif filename == "mpr_je.csv" and folder != "streamdataFirehose":
        jobname = "Job-mpr-je"
    
    elif filename == "prt_mpr_addr_change_dhcs_834.csv" and folder != "streamdataFirehose":
        jobname = "job-prt-mpr-addr-change-dhcs-834"
    
    elif filename == "soc_data.csv" and folder != "streamdataFirehose":
        jobname = "Job-soc-data"
        
    elif filename == "834_mom_ar_bal.csv" and folder == "streamdataFirehose":
        jobname = "Job-834-mom-ar-bal-streamed"
    
    elif filename == "filecomparison.csv" and folder == "streamdataFirehose":
        jobname = "Job-filecomparison-streamed"
    
    elif filename == "mpr_je.csv" and folder == "streamdataFirehose":
        jobname = "Job-mpr-je-streamed"
    
    elif filename == "prt_mpr_addr_change_dhcs_834.csv" and folder == "streamdataFirehose":
        jobname = "Job-prt-mp-addr-change-dhcs-834-streamed"
    
    elif filename == "soc_data.csv" and folder == "streamdataFirehose":
        jobname = "Job-soc-data-streamed"
    
    else:
        jobname = ""

        
    print("DatabrewJobname: " +jobname)

    try:
        runId = databrew.start_job_run(
            Name = jobname
            
                )
    except Exception as e:
        error_msg = str(e)
        # print(error_msg) do required action
        raise e