import json
import os
import boto3
import csv
import urllib.parse
import time


#initiate s3 client 
s3 = boto3.client('s3')
strings_to_remove = ["WebKitFormBoundary", "Content-Disposition", "Content-Type"]


def lambda_handler(event, context):
    print("event collected is {}".format(event))
    print("Received event: " + json.dumps(event, indent=2))
    
    s3_bucket = event['detail']['bucket']['name']
    print("Bucket name is {}".format(s3_bucket))
    
    s3_key = urllib.parse.unquote_plus(event['detail']['object']['key'], encoding='utf-8')
    print("Bucket key name is {}".format(s3_key))
    
    response = s3.get_object(Bucket=s3_bucket, Key=s3_key)
    lines = response['Body'].read().decode('utf-8').splitlines()
    filtered_lines = [line for line in lines if not any(string in line for string in strings_to_remove) and line.strip()]
    output_content = '\n'.join(filtered_lines)
    
    #print(output_content)
    
    folder = "source/"
    prefix = s3_key.split('.')[0]
    
    # Write the output file to S3
    output_bucket = 'integrationframework'  # Replace with your S3 bucket name
    output_key = folder + prefix + "/" + s3_key  # Replace with the desired output file name
    
    print(output_key)
    
    s3.put_object(Bucket=output_bucket, Key=output_key, Body=output_content.encode('utf-8'))
    
    return {
        'statusCode': 200,
        'body': 'Output file created successfully in S3'
    }    